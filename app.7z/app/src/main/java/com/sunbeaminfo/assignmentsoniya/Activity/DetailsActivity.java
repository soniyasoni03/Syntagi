package com.sunbeaminfo.assignmentsoniya.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.sunbeaminfo.assignmentsoniya.R;

/**
 * Created by sunbeam on 14/6/18.
 */

public class DetailsActivity extends AppCompatActivity {
    TextView textTitle;
    TextView textPrice;
    TextView textDescription;
    TextView textCompany;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);


        this.textTitle = (TextView) findViewById(R.id.textTitle);
        this.textDescription = (TextView) findViewById(R.id.textDescription);
        this.textPrice = (TextView) findViewById(R.id.textPrice);
        this.textCompany = (TextView) findViewById(R.id.textCompany);
        /*Medicine product = getIntent().getParcelableExtra("product");
        textTitle.setText(product.getP_name());
        textDescription.setText(product.getP_desc());
        textCompany.setText(product.getP_company());
        textPrice.setText("Rs " + product.getP_price());

*/
        Intent intent = getIntent();
        String p_name = intent.getStringExtra("p_name");
        String p_desc = intent.getStringExtra("p_desc");
        String p_company = intent.getStringExtra("p_company");
        String p_price = intent.getStringExtra("p_price");

        // textTitle.setText("details are: \n"+"name:"+p_name+"\n"+"description:"+p_desc+"\n"+"company:"+p_company+"\n"+"price:"+p_price);
        textTitle.setText("details are:" + "\n" + "name:" + p_name);
        textDescription.setText("description:" + p_desc);
        textCompany.setText("company:" + p_company);
        textPrice.setText("Price:" + p_price);

    }

    public void buynow(View v) {
       // Intent intent1 = new Intent(this, BuyNow.class);
        //startActivity(intent1);
    }





    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
