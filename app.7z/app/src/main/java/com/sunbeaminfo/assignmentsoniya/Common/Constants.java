package com.sunbeaminfo.assignmentsoniya.Common;

/**
 * Created by sunbeam on 14/6/18.
 */

public class Constants {
    public static final String BASE_URL = "http://192.168.43.217:8080/WellnessStore/";

    public static final String RESULT_SUCCESS = "success";
    public static final String RESULT_FAILURE = "failure";
    //public static final String Login = "login";

    public static final String SERVLET_LOGIN = "login";
    public static final String SERVLET_REGISTER = "register";
    public static final String SERVLET_PRODUCT_LIST = "products";
}
