package com.sunbeaminfo.assignmentsoniya.Common;


import com.sunbeaminfo.assignmentsoniya.Model.Medicine;

/**
 * Created by sunbeam on 18/1/18.
 */

public interface ProductClickListener {
    void onProductClick(Medicine medicine);
}
