package com.sunbeaminfo.assignmentsoniya.Model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by sunbeam on 14/6/18.
 */

public class Medicine implements Parcelable {
    private String p_name;
    private String p_desc;
    private String p_company;
    private float p_price;
    public Medicine(){

    }

    public Medicine(String p_name, String p_desc, String p_company, float p_price) {
        this.p_name = p_name;
        this.p_desc = p_desc;
        this.p_company = p_company;
        this.p_price = p_price;
    }

    public Medicine(Parcel source) {
        this.p_name=source.readString();
        this.p_desc=source.readString();
        this.p_company=source.readString();
        this.p_price= (float) source.readValue(Double.class.getClassLoader());
    }

    public String getP_name() {
        return p_name;
    }

    public void setP_name(String p_name) {
        this.p_name = p_name;
    }

    public String getP_desc() {
        return p_desc;
    }

    public void setP_desc(String p_desc) {
        this.p_desc = p_desc;
    }

    public String getP_company() {
        return p_company;
    }

    public void setP_company(String p_company) {
        this.p_company = p_company;
    }

    public float getP_price() {
        return p_price;
    }

    /* @Override
     public String toString() {
         return "Medicine{" +
                 "p_name='" + p_name + '\'' +
                 '}';
     }
    */ @Override
    public String toString(){
        return String.format("Name:"+p_name +"\n"+ "Description:"+p_desc +"\n"+ "company:"+p_company +"\n"+ "\n"+p_price);

    }

    public void setP_price(float p_price) {
        this.p_price = p_price;
    }
    public static final Creator<Medicine> CREATOR = new Creator<Medicine>(){

        @Override
        public Medicine createFromParcel(Parcel source) {
            return new Medicine(source);
        }

        @Override
        public Medicine[] newArray(int size) {
            return new Medicine[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.p_name);
        dest.writeString(this.p_desc);
        dest.writeString(this.p_company);
        dest.writeValue(this.p_price);

    }
}


