package com.sunbeaminfo.assignmentsoniya.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.sunbeaminfo.assignmentsoniya.Common.Constants;
import com.sunbeaminfo.assignmentsoniya.Common.Utils;
import com.sunbeaminfo.assignmentsoniya.Model.Medicine;
import com.sunbeaminfo.assignmentsoniya.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

/**
 * Created by sunbeam on 14/6/18.
 */

public class ProductList extends AppCompatActivity implements AdapterView.OnItemClickListener {
    ArrayList<Medicine> medicines = new ArrayList<>();
    //EditText editsearchText;
    ListView listView;
    ArrayAdapter<Medicine> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        listView= (ListView) findViewById(R.id.listview);
        //adapter=new MedicineAdapter(this,medicines);
        adapter=new ArrayAdapter<Medicine>(this,android.R.layout.simple_list_item_1,medicines);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        medicines.add(new Medicine("aa","aa","aa",2.5f));
        Bundle b=getIntent().getExtras();
        String searchtext=b.getString("searchtext");
        Toast.makeText(this, "text"+searchtext, Toast.LENGTH_SHORT).show();
        new ProductList.DownloadMedicineListTask(searchtext)
                .execute();


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    /*public void onStart(){  c
        super.onStart();
        ListView listView= (ListView) findViewById(R.id.listview);
        new ProductList.DownloadMedicineListTask(getIntent().getStringExtra("search"))
                .execute();
    }
*/
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Medicine medicine=medicines.get(position);
        Intent intent=new Intent(this,DetailsActivity.class);
        intent.putExtra("p_name",medicine.getP_name().toString());
        intent.putExtra("p_desc",medicine.getP_desc().toString());
        intent.putExtra("p_company",medicine.getP_company().toString());
        float price=medicine.getP_price();
        String str2=Float.toString(price);
        Log.d("st",str2);
        intent.putExtra("p_price",str2);
        startActivity(intent);
    }



    class DownloadMedicineListTask extends AsyncTask<Void, Void, String> {
        private final String searchText;
        private ProgressDialog dialog;

        public DownloadMedicineListTask(String searchText) {
            this.searchText = searchText;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(ProductList.this);
            dialog.setTitle("wait..");
            dialog.setMessage("Wait.. Fetching List..");
            dialog.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            String strURL = Utils.createUrl(Constants.SERVLET_PRODUCT_LIST);
            strURL += "?searchText=" + searchText;
            Log.d("const", strURL);

            try {
                URL url = new URL(strURL);
                URLConnection connection = url.openConnection();
                InputStream inputStream = connection.getInputStream();

                String result = Utils.convertInputStream(inputStream);
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            dialog.dismiss();

            medicines.clear();
            Log.d("searchmed",result);

            try {
                JSONArray array = new JSONArray(result);
                for (int index = 0; index < array.length(); index++) {
                    JSONObject object = array.getJSONObject(index);

                    Medicine product = new Medicine();
                    // product.setProductId(object.getInt("id"));
                    product.setP_name(object.getString("p_name"));
                    product.setP_desc(object.getString("p_desc"));
                    product.setP_company(object.getString("p_company"));
                    product.setP_price((float) object.getDouble("p_price"));
                    //  product.setRating((float) object.getDouble("rating"));


                    medicines.add(product);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            adapter.notifyDataSetChanged();

        }
    }
}

