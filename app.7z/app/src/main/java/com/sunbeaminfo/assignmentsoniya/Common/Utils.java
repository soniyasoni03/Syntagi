package com.sunbeaminfo.assignmentsoniya.Common;

import android.provider.SyncStateContract;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by sunbeam on 14/6/18.
 */

public class Utils {
    public static String createUrl(String path)
    {
        return Constants.BASE_URL + path;
    }

        public static String convertInputStream(InputStream stream) {

            StringBuilder builder = new StringBuilder();
            try {

                InputStreamReader reader = new InputStreamReader(stream);
                int ch;
                while((ch = reader.read()) != -1) {
                    builder.append((char)ch);
                }

                reader.close();
                stream.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
            return builder.toString();
        }

}
