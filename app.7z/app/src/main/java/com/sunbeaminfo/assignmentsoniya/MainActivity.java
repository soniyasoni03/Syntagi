package com.sunbeaminfo.assignmentsoniya;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.sunbeaminfo.assignmentsoniya.Activity.ProductList;

import static com.sunbeaminfo.assignmentsoniya.R.id.buttonSearch;

public class MainActivity extends AppCompatActivity {
    EditText editSearchText;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editSearchText = (EditText) findViewById(R.id.editSearchText);

    }
    public void onClick(View v) {
        Bundle b=new Bundle();
        b.putString("searchtext", String.valueOf(editSearchText.getText()));
        Intent intent = new Intent(this, ProductList.class);
        //intent.putExtra("search",editSearchText.getText());
        intent.putExtras(b);
        startActivity(intent);

    }
}
